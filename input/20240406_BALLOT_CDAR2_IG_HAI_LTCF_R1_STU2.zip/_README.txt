This readme is included in a zip file which packages the ballot package of: 
	HL7 CDA� R2 Implementation Guide: 
	National Healthcare Safety Network (NHSN) Healthcare Associated Infection (HAI) Reports 
	for Long Term Care Facilities (HAI-LTCF-CDA), 
	Release 1, STU 2 - US Realm (1.2)

The package was prepared by Lantana Consulting Group, Inc.

NOTE: The date specified in this README file is the Lantana Consulting Group delivery date for this file package. 
Dates on the Implementation Guide cover page and footer will change when the Implementation Guide is balloted or published through HL7. 

========================
Contents of this package:
_README.txt

--Implementation Guide files--
CDAR2_IG_HAI_LTCF_R1_STU2_Vol1.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) background material
CDAR2_IG_HAI_LTCF_R1_STU2_Vol2.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) computable constraints with example code (Figures) and vocabulary OID listing 

======================== GitHub ========================

You will find sample files,schematron validation files, stylesheets and the CDA schema in GitHub: https://github.com/HL7/CDA-hai-ltcf/tree/main/CDA-hai-ltcf-1.2

Note: the XML CDA files will not validate properly at this time due to a proposed extension that isn�t yet in the sdtc Schema, if the proposal is accepted by the ballot commenters and SDWG, this will be rectified prior to publication.
	
-- Sample files ---
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU2_LabIDEvent.xml		Example of MDRO and CDI LabID Event Report
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU2_LabIDEvent.html	HTML rendering of MDRO and CDI LabID Event Report sample file
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU2_LabIDSummary.xml	Example of MDRO and CDI LabID Summary Report
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU2_LabIDSummary.html	HTML rendering of MDRO and CDI LabID Summary Report sample file

--NHSN logo--
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/examples/xml/nhsnlogo_small.gif				     	NHSN Logo displayed on sample file rendering

-- Schematron validation files �-
 
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/validation/CDAR2_IG_HAI_LTCF_R1_STU2.sch			     	Schematron validation file for HAI LTCF IG 
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/validation/CDAR2_IG_HAI_LTCF_R1_STU2.xml		             	Associated vocabulary file for HAI LTCF IG			

-- stylesheet --	
https://github.com/HL7/CDA-hai-ltcf/blob/main/CDA-hai-ltcf-1.2/transform/hai-display.xsl					HAI stylesheet for rendering sample files


-- schema --
The latest release of the CDA Schema can be downloaded from GitHub: https://hl7.org/permalink/?CDAR2.0schema
                           
April 2024
