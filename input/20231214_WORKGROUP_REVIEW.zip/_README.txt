This readme is included in a zip file which packages the unballoted STU update of: 
HL7 CDA� R2 Implementation Guide: National Healthcare Safety Network (NHSN) Healthcare Associated Infection (HAI) Reports for Long Term Care Facilities (HAI-LTCF-CDA), Release 1, US Realm, STU 1.2
Please extract and place all of the supplied files in a folder together for use.

The package was prepared by Lantana Consulting Group, Inc.

NOTE: The date specified in this README file is the Lantana Consulting Group delivery date for this file package. 
Dates on the Implementation Guide cover page and footer will change when the Implementation Guide is balloted or published through HL7. 

========================
Contents of this package:
_README.txt

--Implementation Guide files--
CDAR2_IG_HAI_LTCF_R1_STU1.2_Vol1.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) background material
CDAR2_IG_HAI_LTCF_R1_STU1.2_Vol2.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) computable constraints with example code (Figures) and vocabulary OID listing 

======================== GitHub ========================

You will find sample files,schematron validation files, stylesheets and the CDA schema in GitHub: https://github.com/HL7/CDAR2_IG_HAI_LTCF_R1_D1/tree/CDA-hai-ltcf-1.1.2
 
	
-- Sample files ---
examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU1_2_LabIDEvent.xml           Example of MDRO and CDI LabID Event Report
examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU1_2_LabIDEvent.html         HTML rendering of MDRO and CDI LabID Event Report sample file
examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU1_2_LabIDSummary.xml	     Example of MDRO and CDI LabID Summary Report
examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU1_2_LabIDSummary.html	     HTML rendering of MDRO and CDI LabID Summary Report sample file

--NHSN logo--
examples/xml/nhsnlogo_small.gif					     NHSN Logo displayed on sample file rendering

-- Schematron validation files�
 
validation/CDAR2_IG_HAI_LTCF_R1_STU1_2.sch			     Schematron validation file for HAI LTCF IG 
validation/CDAR2_IG_HAI_LTCF_R1_STU1_2.xml		             Associated vocabulary file for HAI LTCF IG			

--stylesheet--	
hai-display.xsl						             HAI stylesheet for rendering sample files ()
generate-narrative-ltc.xsl				             Narrrative text generator ()


--schema--
The latest release of the CDA Schema can be downloaded from GitHub:                 https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions/SDTC
                           
December 2023
