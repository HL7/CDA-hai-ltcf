This readme is included in a zip file which packages the 1st unballoted STU update of: 
HL7 CDA� R2 Implementation Guide: 
National Healthcare Safety Network (NHSN) Healthcare Associated Infection (HAI) Reports for Long Term Care Facilities (HAI-LTCF-CDA), Release 1, US Realm, STU 1.1.
Please extract and place all of the supplied files in a folder together for use.

The package was prepared by Lantana Consulting Group, Inc.

NOTE: The date specified in this README file is the Lantana Consulting Group delivery date for this file package. 
Dates on the Implementation Guide cover page and footer will change when the Implementation Guide is balloted or published through HL7. 

========================
Contents of this package:
_README.txt

--Implementation Guide files--
CDAR2_IG_HAI_LTCF_R1_STU1.1_Vol1.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) background material
CDAR2_IG_HAI_LTCF_R1_STU1.1_Vol2.docx     The NHSN Healthcare Associated Infection (HAI) Long Term Care Facility (LTCF) Implementation Guide (IG) computable constraints with example code (Figures) and vocabulary OID listing 

======================== GForge ========================

You will find sample files,schematron validation files, stylesheets and the CDA schema in Git: https://github.com/HL7/CDAR2_IG_HAI_LTCF_R1_D1/tree/CDA-hai-ltcf-1.1.1

-- Sample files ---
examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU1_1_LabIDEvent.xml           Example of MDRO and CDI LabID Event Report
examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU1_1_LabIDEvent.html         Example of MDRO and CDI LabID Event Report

examples/xml/CDAR2_IG_HAI_LTCFRPT_R1_STU1_1_LabIDSummary.xml         Example of MDRO and CDI LabID Summary Report
examples/html/CDAR2_IG_HAI_LTCFRPT_R1_STU1_1_LabIDSummary.html       Example of MDRO and CDI LabID Summary Report

--NHSN logo--
examples/xml/nhsnlogo_small.gif                                      NHSN Logo displayed on sample file rendering

-- Schematron validation files�
validation/CDAR2_IG_HAI_LTCF_R1_STU1_1.sch                           Schematron validation file for HAI LTCF IG 
validation/CDAR2_IG_HAI_LTCF_R1_STU1_1.xml                           Associated vocabulary file for HAI LTCF IG            

--stylesheet--    
transform/hai-display.xsl                                            HAI stylesheet for rendering sample files

--schema--
The latest release of the CDA Schema can be downloaded from GitHub:  https://github.com/HL7/cda-core-2.0/tree/master/schema/extensions
                           
February 2023
